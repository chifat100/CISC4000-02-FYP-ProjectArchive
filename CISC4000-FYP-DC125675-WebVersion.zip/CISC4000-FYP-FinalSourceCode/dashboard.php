<?php
   session_start();

   error_reporting(E_ALL);
   ini_set('display_errors', 1);
   if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
      header("location: loginTest.php");
      exit;
   }

   require_once "php/config.php";

   // Fetch user data including profile picture
   $sql = "SELECT * FROM users WHERE id = :id";

   function updateLastLogin($pdo, $user_id) {
      $sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
      $stmt = $pdo->prepare($sql);
      $stmt->execute([$user_id]);
    }

   if($stmt = $pdo->prepare($sql)){
      $stmt->bindParam(":id", $_SESSION["id"], PDO::PARAM_INT);
      if($stmt->execute()){
        $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
        // Update session with profile picture if not set
        if(!isset($_SESSION['profile_picture']) && !empty($user_data['profile_picture'])){
            $_SESSION['profile_picture'] = $user_data['profile_picture'];
        }
      }
   }

   $upload_dir = 'uploads/profile_pictures/';
   if(!file_exists($upload_dir)) {
      mkdir($upload_dir, 0755, true);
   }

   function getProfileImage($user_data) {
      $default_image = 'images/default-avatar.png';
    
      if(!empty($user_data['profile_picture'])) {
         $image_path = 'uploads/profile_pictures/'.$user_data['profile_picture'];
         if(file_exists($image_path)) {
            return $image_path;
         }
      }
      return $default_image;
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
   <link rel="stylesheet" href="css/lms.css">

</head>
<body>

   <header class="header">
      
      <section class="flex">

         <a href="dashboard.php" class="logo">EduSync</a>

         <form action="search.html" method="post" class="search-form">
            <input type="text" name="search_box" required placeholder="search courses..." maxlength="100">
            <button type="submit" class="fas fa-search"></button>
         </form>

         <div class="icons">
            <div id="menu-btn" class="fas fa-bars"></div>
            <div id="search-btn" class="fas fa-search"></div>
            <div id="user-btn" class="fas fa-user"></div>
            <div id="toggle-btn" class="fas fa-sun"></div>
         </div>

         <div class="profile">
            <img src="<?php 
               if(!empty($user_data['profile_picture']) && file_exists('uploads/profile_pictures/'.$user_data['profile_picture'])){
                  echo 'uploads/profile_pictures/'.$user_data['profile_picture'];
               } else {
                  echo 'images/pic-1.jpg'; 
               }
            ?>" alt="Profile Picture">
            <h3 class="name"><?php echo htmlspecialchars($_SESSION["name"]); ?></h3>
            <p class="role"><?php echo htmlspecialchars($_SESSION["profile_type"]); ?></p>
            <a href="profile.php" class="btn">view profile</a>
            <div class="flex-btn">
               <a href="logout.php" class="option-btn">Logout</a>
            </div>
         </div>
      </section>

   </header>   

   <div class="side-bar">

      <div id="close-btn">
         <i class="fas fa-times"></i>
      </div>

      <div class="profile">
         <img src="<?php 
            if(!empty($user_data['profile_picture']) && file_exists('uploads/profile_pictures/'.$user_data['profile_picture'])){
               echo 'uploads/profile_pictures/'.$user_data['profile_picture'];
            } else {
               echo 'images/default-avatar.png'; 
            }
         ?>" alt="Profile Picture">

         <h3 class="name"><?php echo htmlspecialchars($_SESSION["name"]); ?></h3>
         <p class="role"><?php echo htmlspecialchars($_SESSION["profile_type"]); ?></p>

         <a href="profile.php" class="btn">view profile</a>
      </div>

      <nav class="navbar">
         <a href="dashboard.php"><i class="fas fa-home"></i><span>home</span></a>
         <a href="student_WS.php"><i class="fa-solid fa-person-digging"></i><span>workspace</span></a>
         <a href="courses.php"><i class="fas fa-graduation-cap"></i><span>courses</span></a>
         <a href="forum.php"><i class="fas fa-headset"></i><span>discussion</span></a>
         <a href="blog.php"><i class="fas fa-headset"></i><span>Blog</span></a>
      </nav>

   </div>

   <section class="home-grid">

      <h1 class="heading">quick options</h1>

      <div class="box-container">

         <div class="box">
            <h3 class="title">likes and comments</h3>
            <p class="likes">total likes : <span>25</span></p>
            <a href="#" class="inline-btn">view likes</a>
            <p class="likes">total comments : <span>12</span></p>
            <a href="#" class="inline-btn">view comments</a>
            <p class="likes">saved playlists : <span>4</span></p>
            <a href="#" class="inline-btn">view playlists</a>
         </div>

         <div class="box">
            <h3 class="title">top categories</h3>
            <div class="flex">
               <a href="#"><i class="fas fa-code"></i><span>development</span></a>
               <a href="#"><i class="fas fa-chart-simple"></i><span>business</span></a>
               <a href="#"><i class="fas fa-pen"></i><span>design</span></a>
               <a href="#"><i class="fas fa-chart-line"></i><span>marketing</span></a>
               <a href="#"><i class="fas fa-music"></i><span>music</span></a>
               <a href="#"><i class="fas fa-camera"></i><span>photography</span></a>
               <a href="#"><i class="fas fa-cog"></i><span>software</span></a>
               <a href="#"><i class="fas fa-vial"></i><span>science</span></a>
            </div>
         </div>

         <div class="box">
            <h3 class="title">popular topics</h3>
            <div class="flex">
               <a href="#"><i class="fab fa-html5"></i><span>HTML</span></a>
               <a href="#"><i class="fab fa-css3"></i><span>CSS</span></a>
               <a href="#"><i class="fab fa-js"></i><span>javascript</span></a>
               <a href="#"><i class="fab fa-react"></i><span>react</span></a>
               <a href="#"><i class="fab fa-php"></i><span>PHP</span></a>
               <a href="#"><i class="fab fa-bootstrap"></i><span>bootstrap</span></a>
            </div>
         </div>

      </div>

   </section>

   <section class="courses">

      <h1 class="heading">our courses</h1>

      <div class="box-container">

         <div class="box">
            <div class="tutor">
               <img src="images/pic-2.jpg" alt="">
               <div class="info">
                  <h3>john deo</h3>
                  <span>21-10-2022</span>
               </div>
            </div>
            <div class="thumb">
               <img src="images/thumb-1.png" alt="">
               <span>10 videos</span>
            </div>
            <h3 class="title">complete HTML tutorial</h3>
            <a href="playlist.html" class="inline-btn">view playlist</a>
         </div>

         <div class="box">
            <div class="tutor">
               <img src="images/pic-3.jpg" alt="">
               <div class="info">
                  <h3>john deo</h3>
                  <span>21-10-2022</span>
               </div>
            </div>
            <div class="thumb">
               <img src="images/thumb-2.png" alt="">
               <span>10 videos</span>
            </div>
            <h3 class="title">complete CSS tutorial</h3>
            <a href="playlist.html" class="inline-btn">view playlist</a>
         </div>

         <div class="box">
            <div class="tutor">
               <img src="images/pic-4.jpg" alt="">
               <div class="info">
                  <h3>john deo</h3>
                  <span>21-10-2022</span>
               </div>
            </div>
            <div class="thumb">
               <img src="images/thumb-3.png" alt="">
               <span>10 videos</span>
            </div>
            <h3 class="title">complete JS tutorial</h3>
            <a href="playlist.html" class="inline-btn">view playlist</a>
         </div>

         <div class="box">
            <div class="tutor">
               <img src="images/pic-5.jpg" alt="">
               <div class="info">
                  <h3>john deo</h3>
                  <span>21-10-2022</span>
               </div>
            </div>
            <div class="thumb">
               <img src="images/thumb-4.png" alt="">
               <span>10 videos</span>
            </div>
            <h3 class="title">complete Boostrap tutorial</h3>
            <a href="playlist.html" class="inline-btn">view playlist</a>
         </div>

         <div class="box">
            <div class="tutor">
               <img src="images/pic-6.jpg" alt="">
               <div class="info">
                  <h3>john deo</h3>
                  <span>21-10-2022</span>
               </div>
            </div>
            <div class="thumb">
               <img src="images/thumb-5.png" alt="">
               <span>10 videos</span>
            </div>
            <h3 class="title">complete JQuery tutorial</h3>
            <a href="playlist.html" class="inline-btn">view playlist</a>
         </div>

         <div class="box">
            <div class="tutor">
               <img src="images/pic-7.jpg" alt="">
               <div class="info">
                  <h3>john deo</h3>
                  <span>21-10-2022</span>
               </div>
            </div>
            <div class="thumb">
               <img src="images/thumb-6.png" alt="">
               <span>10 videos</span>
            </div>
            <h3 class="title">complete SASS tutorial</h3>
            <a href="playlist.html" class="inline-btn">view playlist</a>
         </div>

      </div>

      <div class="more-btn">
         <a href="courses.html" class="inline-option-btn">view all courses</a>
      </div>

   </section>

   <footer class="footer">

      &copy; copyright @ 2025 by <span>EduSync</span> |

   </footer>
   
   <script src="js/script.js"></script>
 
</body>
</html>