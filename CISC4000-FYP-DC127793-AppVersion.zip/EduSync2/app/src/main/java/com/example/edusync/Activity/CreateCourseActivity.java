package com.example.edusync.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class CreateCourseActivity extends AppCompatActivity {

    private EditText etCourseCode, etCourseName, etDescription;
    private Button btnSaveCourse;
    private ImageView btnBack; // 更改为 ImageView 类型

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_course);

        // 初始化 UI 元件
        etCourseCode = findViewById(R.id.etCourseCode);
        etCourseName = findViewById(R.id.etCourseName);
        etDescription = findViewById(R.id.etCourseDescription);
        btnSaveCourse = findViewById(R.id.btnSaveCourse);
        btnBack = findViewById(R.id.btnBack); // 初始化 btnBack

        // 设置保存按钮的点击事件
        btnSaveCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCourseToDatabase();
            }
        });

        // 设置返回按钮（ImageView）的点击事件
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToInstructorCourseActivity();
            }
        });
    }

    private void saveCourseToDatabase() {
        // 获取用户输入的数据
        String courseCode = etCourseCode.getText().toString().trim();
        String courseName = etCourseName.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        // 验证输入是否为空
        if (TextUtils.isEmpty(courseCode)) {
            Toast.makeText(this, "课程代码不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(courseName)) {
            Toast.makeText(this, "课程名称不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        // 从 SharedPreferences 获取当前登录用户的 user_id 作为 instructor_id
        int instructorId = getInstructorId();
        if (instructorId == -1) {
            Toast.makeText(this, "无法获取用户 ID，请重新登录", Toast.LENGTH_SHORT).show();
            return;
        }

        MysqlConnect mysqlConnect = new MysqlConnect();
        Connection conn = mysqlConnect.CONN();

        if (conn != null) {
            try {
                String query = "INSERT INTO courses (course_code, course_name, description, instructor_id, rating) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, courseCode);
                stmt.setString(2, courseName);
                stmt.setString(3, description);
                stmt.setInt(4, instructorId);
                stmt.setDouble(5, 0.0);

                if (stmt.executeUpdate() > 0) {
                    Toast.makeText(this, "课程添加成功！", Toast.LENGTH_SHORT).show();
                    navigateToInstructorCourseActivity();
                } else {
                    Toast.makeText(this, "课程添加失败！", Toast.LENGTH_SHORT).show();
                }

                stmt.close();
                conn.close();
            } catch (Exception e) {
                Log.e("CreateCourseActivity", "Error: " + e.getMessage());
                Toast.makeText(this, "发生错误：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "无法连接到数据库", Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToInstructorCourseActivity() {
        Intent intent = new Intent(CreateCourseActivity.this, InstructorCourseActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private int getInstructorId() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        return sharedPreferences.getInt("user_id", -1);
    }
}