package com.example.edusync.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginActivity extends AppCompatActivity {
    private MysqlConnect mySQLConnect;
    private Connection con;

    private EditText etUsername, etPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mySQLConnect = new MysqlConnect();

        // 初始化 UI 组件
        etUsername = findViewById(R.id.username);
        etPassword = findViewById(R.id.password);
        btnLogin = findViewById(R.id.btn_login2);

        // 初始禁用登录按钮
        btnLogin.setEnabled(false);

        // 实时监控输入框内容变化，启用登录按钮
        etUsername.addTextChangedListener(new SimpleTextWatcher(this::validateInput));
        etPassword.addTextChangedListener(new SimpleTextWatcher(this::validateInput));

        // 设置登录按钮的点击事件
        btnLogin.setOnClickListener(view -> handleLogin());

        // 忘记密码跳转
        TextView forgetPasswordText = findViewById(R.id.textViewForget1);
        forgetPasswordText.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
            startActivity(intent);
        });
    }

    /**
     * 验证输入框内容是否为空
     */
    private void validateInput() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // 如果用户名和密码都非空，则启用登录按钮
        btnLogin.setEnabled(!TextUtils.isEmpty(username) && !TextUtils.isEmpty(password));
    }

    /**
     * 登录逻辑
     */
    private void handleLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "请输入用户名和密码", Toast.LENGTH_SHORT).show();
            return;
        }

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                con = mySQLConnect.CONN();
                if (con != null) {
                    String query = "SELECT * FROM users WHERE (LOWER(email) = LOWER(?) OR LOWER(name) = LOWER(?)) AND password = ?";
                    PreparedStatement preparedStatement = con.prepareStatement(query);
                    preparedStatement.setString(1, username);
                    preparedStatement.setString(2, username);
                    preparedStatement.setString(3, password); // 建议改为哈希值

                    ResultSet resultSet = preparedStatement.executeQuery();

                    if (resultSet.next()) {
                        int userId = resultSet.getInt("id");
                        String profileType = resultSet.getString("profile_type");

                        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putInt("user_id", userId); // 保存用户 ID
                        editor.putString("profile_type", profileType); // 保存用户类型
                        editor.apply();

                        runOnUiThread(() -> {
                            Toast.makeText(this, "登录成功！", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        });
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "用户名或密码错误", Toast.LENGTH_SHORT).show());
                    }

                    resultSet.close();
                    preparedStatement.close();
                    con.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "数据库连接失败", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "发生错误：" + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }
}