package com.example.edusync.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Activity.AssignmentGradingActivity;
import com.example.edusync.Activity.AssignmentSubmitActivity;
import com.example.edusync.Domain.AssignmentModel;
import com.example.edusync.R;

import java.util.ArrayList;

public class AssignmentAdapter extends RecyclerView.Adapter<AssignmentAdapter.AssignmentViewHolder> {

    private ArrayList<AssignmentModel> assignmentList;
    private Context context;

    public AssignmentAdapter(ArrayList<AssignmentModel> assignmentList, Context context) {
        this.assignmentList = assignmentList;
        this.context = context;
    }

    @NonNull
    @Override
    public AssignmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_assignment, parent, false);
        return new AssignmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AssignmentViewHolder holder, int position) {
        AssignmentModel assignment = assignmentList.get(position);

        // 设置 Title、Creator 和 Due Date
        holder.assignmentTitleTextView.setText(assignment.getTitle());
        holder.assignmentCreatorTextView.setText("Created by: " + assignment.getCreator());
        holder.dueDateTextView.setText("Due Date: " + assignment.getDueDate());

        // 设置点击事件监听器
        holder.itemView.setOnClickListener(v -> {
            // 获取用户类型
            SharedPreferences sharedPreferences = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
            String profileType = sharedPreferences.getString("profile_type", "student"); // 默认类型为 student

            // 根据用户类型跳转到不同的活动
            if ("student".equals(profileType)) {
                Intent intent = new Intent(context, AssignmentSubmitActivity.class);
                intent.putExtra("assignment_id", assignment.getId());
                intent.putExtra("assignment_title", assignment.getTitle());
                intent.putExtra("assignment_creator", assignment.getCreator());
                intent.putExtra("assignment_due_date", assignment.getDueDate());
                context.startActivity(intent);
            } else if ("instructor".equals(profileType)) {
                Intent intent = new Intent(context, AssignmentGradingActivity.class);
                intent.putExtra("assignment_id", assignment.getId());
                intent.putExtra("assignment_title", assignment.getTitle());
                intent.putExtra("assignment_creator", assignment.getCreator());
                intent.putExtra("assignment_due_date", assignment.getDueDate());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return assignmentList.size();
    }

    public static class AssignmentViewHolder extends RecyclerView.ViewHolder {
        TextView assignmentTitleTextView, assignmentCreatorTextView, dueDateTextView;

        public AssignmentViewHolder(@NonNull View itemView) {
            super(itemView);
            assignmentTitleTextView = itemView.findViewById(R.id.titleTV);
            assignmentCreatorTextView = itemView.findViewById(R.id.creatorTV);
            dueDateTextView = itemView.findViewById(R.id.duedateTV);
        }
    }
}