package com.example.edusync.Activity;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Adapter.StudentAdapter;
import com.example.edusync.Domain.Student;
import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class StudentListActivity extends AppCompatActivity {

    private RecyclerView recyclerViewStudents;
    private StudentAdapter studentAdapter;
    private List<Student> studentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);

        // 初始化 RecyclerView
        recyclerViewStudents = findViewById(R.id.recyclerViewStudents);
        recyclerViewStudents.setLayoutManager(new LinearLayoutManager(this));

        // 初始化学生列表
        studentList = new ArrayList<>();

        // 获取课程代码
        String courseCode = getIntent().getStringExtra("course_code");

        // 验证课程代码
        if (courseCode == null || courseCode.isEmpty()) {
            Toast.makeText(this, "Invalid course code", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 加载学生列表
        loadStudentList(courseCode);
    }

    private void loadStudentList(String courseCode) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                MysqlConnect mysqlConnect = new MysqlConnect();
                Connection conn = mysqlConnect.CONN();

                if (conn != null) {
                    // 查询课程 ID
                    String courseQuery = "SELECT id FROM courses WHERE course_code = ?";
                    PreparedStatement courseStmt = conn.prepareStatement(courseQuery);
                    courseStmt.setString(1, courseCode);

                    ResultSet courseRs = courseStmt.executeQuery();
                    int courseId = -1;

                    if (courseRs.next()) {
                        courseId = courseRs.getInt("id");
                    }

                    courseRs.close();
                    courseStmt.close();

                    if (courseId == -1) {
                        runOnUiThread(() -> Toast.makeText(this, "Course not found", Toast.LENGTH_SHORT).show());
                        return;
                    }

                    // 查询学生数据
                    String studentQuery = "SELECT u.id, u.name, u.email " +
                            "FROM enrollments e " +
                            "JOIN users u ON e.student_id = u.id " +
                            "WHERE e.course_id = ? AND u.status = 'active'";
                    PreparedStatement studentStmt = conn.prepareStatement(studentQuery);
                    studentStmt.setInt(1, courseId);

                    ResultSet studentRs = studentStmt.executeQuery();
                    studentList.clear();

                    while (studentRs.next()) {
                        int studentId = studentRs.getInt("id");
                        String name = studentRs.getString("name");
                        String email = studentRs.getString("email");

                        studentList.add(new Student(name, String.valueOf(studentId), email));
                    }

                    studentRs.close();
                    studentStmt.close();
                    conn.close();

                    // 更新 UI
                    runOnUiThread(() -> {
                        if (studentAdapter == null) {
                            studentAdapter = new StudentAdapter(studentList);
                            recyclerViewStudents.setAdapter(studentAdapter);
                        } else {
                            studentAdapter.updateStudentList(studentList);
                        }
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Failed to load student list", Toast.LENGTH_SHORT).show());
            }
        });
    }
}