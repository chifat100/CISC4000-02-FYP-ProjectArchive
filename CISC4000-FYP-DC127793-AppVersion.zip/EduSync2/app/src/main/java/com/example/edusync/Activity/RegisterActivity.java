package com.example.edusync.Activity;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

public class RegisterActivity extends Activity {

    private EditText etName, etEmail, etPassword, etConfirmPassword, etVerificationCode;
    private Button btnRegister, btnSendVerificationCode;
    private String generatedCode; // 保存生成的验证码

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 初始化 UI 组件
        etName = findViewById(R.id.username);
        etEmail = findViewById(R.id.email);
        etPassword = findViewById(R.id.password);
        etConfirmPassword = findViewById(R.id.confirmpassword);
        etVerificationCode = findViewById(R.id.verifycode); // 验证码输入框
        btnRegister = findViewById(R.id.btnregister);
        btnSendVerificationCode = findViewById(R.id.btnSend); // 发送验证码按钮

        // 默认禁用注册按钮
        btnRegister.setEnabled(false);

        // 密码实时验证
        etPassword.addTextChangedListener(passwordTextWatcher);
        etConfirmPassword.addTextChangedListener(passwordTextWatcher);

        // 点击发送验证码按钮
        btnSendVerificationCode.setOnClickListener(v -> {
            sendVerificationCode();
            startCountdown(); // 开始倒计时
        });
        // 点击注册按钮
        btnRegister.setOnClickListener(v -> registerUser());
    }

    /**
     * 实时验证密码
     */
    private final TextWatcher passwordTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String password = etPassword.getText().toString().trim();
            String confirmPassword = etConfirmPassword.getText().toString().trim();

            // 检查密码是否匹配
            if (!password.equals(confirmPassword)) {
                btnRegister.setEnabled(false);
                etConfirmPassword.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_ATOP);
            } else {
                btnRegister.setEnabled(true);
                etConfirmPassword.getBackground().setColorFilter(null);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {}
    };

    /**
     * 发送验证码到用户邮箱
     */
    private void sendVerificationCode() {
        String email = etEmail.getText().toString().trim();

        if (email.isEmpty()) {
            Toast.makeText(this, "请输入邮箱", Toast.LENGTH_SHORT).show();
            return;
        }

        // 生成随机验证码
        generatedCode = String.format("%06d", new Random().nextInt(1000000));

        // 使用 EmailSender 类发送邮件
        new Thread(() -> {
            try {
                EmailSender.sendEmail(email, "注册验证码", "您的验证码是：" + generatedCode);
                runOnUiThread(() -> Toast.makeText(this, "验证码已发送到您的邮箱", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                Log.e("RegisterActivity", "邮件发送失败", e);
                runOnUiThread(() -> Toast.makeText(this, "邮件发送失败：" + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }
    private void startCountdown() {
        // 禁用按钮
        btnSendVerificationCode.setEnabled(false);
        btnSendVerificationCode.setTextColor(Color.GRAY); // 设置按钮文字颜色为灰色

        // 使用 CountDownTimer 进行倒计时
        new CountDownTimer(60000, 1000) { // 参数：总时间 60s，倒计时间隔 1s
            @Override
            public void onTick(long millisUntilFinished) {
                // 每次倒计时更新按钮文字
                btnSendVerificationCode.setText(millisUntilFinished / 1000 + "s");
            }

            @Override
            public void onFinish() {
                // 倒计时结束，恢复按钮状态
                btnSendVerificationCode.setEnabled(true);
                btnSendVerificationCode.setText("发送验证码");
                btnSendVerificationCode.setTextColor(Color.BLACK); // 恢复按钮文字颜色
            }
        }.start();
    }

    /**
     * 验证用户输入的验证码并注册用户
     */
    private void registerUser() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String inputCode = etVerificationCode.getText().toString().trim();

        // 验证输入
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || inputCode.isEmpty()) {
            Toast.makeText(this, "所有字段均为必填项", Toast.LENGTH_SHORT).show();
            return;
        }

        // 验证验证码
        if (!inputCode.equals(generatedCode)) {
            Toast.makeText(this, "验证码错误", Toast.LENGTH_SHORT).show();
            return;
        }

        MysqlConnect mysqlConnect = new MysqlConnect();
        Connection conn = mysqlConnect.CONN();

        if (conn != null) {
            try {
                // 检查邮箱是否已存在
                String checkEmailQuery = "SELECT COUNT(*) AS count FROM users WHERE email = ?";
                PreparedStatement checkEmailStmt = conn.prepareStatement(checkEmailQuery);
                checkEmailStmt.setString(1, email);

                ResultSet rs = checkEmailStmt.executeQuery();
                if (rs.next() && rs.getInt("count") > 0) {
                    Toast.makeText(this, "邮箱已被注册", Toast.LENGTH_SHORT).show();
                    rs.close();
                    checkEmailStmt.close();
                    return;
                }
                rs.close();
                checkEmailStmt.close();

                // 插入新用户到数据库
                String insertQuery = "INSERT INTO users (name, email, password, profile_type, verified, status) VALUES (?, ?, ?, 'student', 1, 'active')";
                PreparedStatement insertStmt = conn.prepareStatement(insertQuery);

                insertStmt.setString(1, name);
                insertStmt.setString(2, email);
                insertStmt.setString(3, password); // 建议对密码进行哈希处理

                int rowsInserted = insertStmt.executeUpdate();
                if (rowsInserted > 0) {
                    Toast.makeText(this, "注册成功！", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "注册失败！", Toast.LENGTH_SHORT).show();
                }

                insertStmt.close();
                conn.close();
            } catch (Exception e) {
                Log.e("RegisterActivity", "错误：" + e.getMessage());
                Toast.makeText(this, "发生错误：" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "数据库连接失败", Toast.LENGTH_SHORT).show();
        }
    }
}