package com.example.edusync.Activity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.edusync.Activity.EmailSender;
import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ForgetPasswordActivity extends AppCompatActivity {

    private EditText etEmail, etPassword, etConfirmPassword, etVerificationCode;
    private Button btnSendVerificationCode, btnResetPassword;
    private MysqlConnect mySQLConnect;

    private String generatedCode; // Holds the generated verification code for comparison

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        mySQLConnect = new MysqlConnect();

        // Initialize UI components
        etEmail = findViewById(R.id.email);
        etPassword = findViewById(R.id.password);
        etConfirmPassword = findViewById(R.id.confirmpassword);
        etVerificationCode = findViewById(R.id.verifycode); // New field for verification code
        btnSendVerificationCode = findViewById(R.id.btnsend); // Button to send code
        btnResetPassword = findViewById(R.id.btnreset);

        // Send verification code
        btnSendVerificationCode.setOnClickListener(v -> {
            sendVerificationCode();
            startCountdown(); // 开始倒计时
        });

        // Reset password
        btnResetPassword.setOnClickListener(view -> resetPassword());

        // Return to login
        TextView backToLogin = findViewById(R.id.textViewRegister1);
        backToLogin.setOnClickListener(view -> finish());
    }

    private void sendVerificationCode() {
        String email = etEmail.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the email exists in the database
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                Connection con = mySQLConnect.CONN();
                if (con != null) {
                    String checkEmailQuery = "SELECT * FROM users WHERE email = ?";
                    PreparedStatement checkStmt = con.prepareStatement(checkEmailQuery);
                    checkStmt.setString(1, email);
                    ResultSet resultSet = checkStmt.executeQuery();

                    if (resultSet.next()) {
                        // Generate a random 6-digit verification code
                        generatedCode = String.format("%06d", new Random().nextInt(1000000));

                        // Send the verification code via email (you need to implement EmailSender)
                        EmailSender.sendEmail(email, "Password Reset Verification Code",
                                "Your verification code is: " + generatedCode);

                        runOnUiThread(() -> Toast.makeText(this, "Verification code sent to your email", Toast.LENGTH_SHORT).show());
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "Email not found", Toast.LENGTH_SHORT).show());
                    }

                    resultSet.close();
                    checkStmt.close();
                    con.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "An error occurred: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }
    private void startCountdown() {
        // 禁用按钮
        btnSendVerificationCode.setEnabled(false);
        btnSendVerificationCode.setTextColor(Color.GRAY); // 设置按钮文字颜色为灰色

        // 使用 CountDownTimer 进行倒计时
        new CountDownTimer(60000, 1000) { // 参数：总时间 60s，倒计时间隔 1s
            @Override
            public void onTick(long millisUntilFinished) {
                // 每次倒计时更新按钮文字
                btnSendVerificationCode.setText(millisUntilFinished / 1000 + "s");
            }

            @Override
            public void onFinish() {
                // 倒计时结束，恢复按钮状态
                btnSendVerificationCode.setEnabled(true);
                btnSendVerificationCode.setText("发送验证码");
                btnSendVerificationCode.setTextColor(Color.BLACK); // 恢复按钮文字颜色
            }
        }.start();
    }

    private void resetPassword() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();
        String verificationCode = etVerificationCode.getText().toString().trim();

        // Validate input fields
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword) || TextUtils.isEmpty(verificationCode)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!verificationCode.equals(generatedCode)) {
            Toast.makeText(this, "Invalid verification code", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform password reset in a background thread
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                Connection con = mySQLConnect.CONN();
                if (con != null) {
                    // Update the password in the database
                    String updatePasswordQuery = "UPDATE users SET password = ? WHERE email = ?";
                    PreparedStatement updateStmt = con.prepareStatement(updatePasswordQuery);
                    updateStmt.setString(1, password); // Use hashPassword(password) if hashing passwords
                    updateStmt.setString(2, email);
                    updateStmt.executeUpdate();

                    runOnUiThread(() -> {
                        Toast.makeText(this, "Password reset successfully", Toast.LENGTH_SHORT).show();
                        finish(); // Return to the login screen
                    });

                    updateStmt.close();
                    con.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "An error occurred: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }
}