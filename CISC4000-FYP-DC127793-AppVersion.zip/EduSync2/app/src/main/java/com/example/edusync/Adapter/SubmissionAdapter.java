package com.example.edusync.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Domain.Submission;
import com.example.edusync.R;

import java.util.List;

public class SubmissionAdapter extends RecyclerView.Adapter<SubmissionAdapter.SubmissionViewHolder> {

    private List<Submission> submissionList;
    private OnItemClickListener listener;

    public SubmissionAdapter(List<Submission> submissionList) {
        this.submissionList = submissionList;
        this.listener = listener;
    }
    public SubmissionAdapter(List<Submission> submissionList, OnItemClickListener listener) {
        this.submissionList = submissionList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public SubmissionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_submission, parent, false);
        return new SubmissionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SubmissionViewHolder holder, int position) {
        Submission submission = submissionList.get(position);
        holder.studentNameTextView.setText(submission.getStudentName());
        holder.fileNameTextView.setText("Title: " + submission.getFileName()); // 显示 title
        holder.statusTextView.setText("Status: " + submission.getStatus());
        holder.gradeTextView.setText("Grade: " + submission.getGrade());
        holder.submissionTimeTextView.setText("Submitted on: " + submission.getSubmissionTime());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(submission); // 回调点击事件
            }
        });
    }

    @Override
    public int getItemCount() {
        return submissionList.size();
    }
    public interface OnItemClickListener {
        void onItemClick(Submission submission);
    }

    static class SubmissionViewHolder extends RecyclerView.ViewHolder {
        TextView studentNameTextView, fileNameTextView, statusTextView, gradeTextView, submissionTimeTextView;

        public SubmissionViewHolder(@NonNull View itemView) {
            super(itemView);
            studentNameTextView = itemView.findViewById(R.id.tvStudentName);
            fileNameTextView = itemView.findViewById(R.id.tvFileName);
            statusTextView = itemView.findViewById(R.id.tvState);
            gradeTextView = itemView.findViewById(R.id.tvGrade);
            submissionTimeTextView = itemView.findViewById(R.id.tvSubmissionTime);
        }
    }
}