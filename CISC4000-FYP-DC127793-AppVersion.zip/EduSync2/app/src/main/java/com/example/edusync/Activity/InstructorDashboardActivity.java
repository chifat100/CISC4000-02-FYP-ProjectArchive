package com.example.edusync.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Adapter.AssignmentAdapter;
import com.example.edusync.Adapter.ResourceAdapter;
import com.example.edusync.Domain.AssignmentModel;
import com.example.edusync.Domain.ResourceModel;
import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InstructorDashboardActivity extends AppCompatActivity {

    private TextView courseCodeTextView, courseNameTextView, instructorNameTextView, studentListTextView;
    private Button btnAssignmentUpload, btnMaterialUpload;
    private RecyclerView materialRecyclerView, assignmentRecyclerView;
    private ResourceAdapter resourceAdapter;
    private AssignmentAdapter assignmentAdapter;
    private ArrayList<ResourceModel> resourceList;
    private ArrayList<AssignmentModel> assignmentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_instructor);

        // 初始化 UI 元素
        initUI();

        // 获取 Intent 数据
        String courseCode = getIntent().getStringExtra("course_code");
        String courseName = getIntent().getStringExtra("course_name");
        String instructorName = getIntent().getStringExtra("instructor_name");

        if (courseCode == null || courseCode.isEmpty()) {
            Toast.makeText(this, "Invalid course code", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        courseCodeTextView.setText(courseCode);
        courseNameTextView.setText(courseName);
        instructorNameTextView.setText(instructorName);

        // 加载教学资源和作业
        loadTeachingResources(courseCode);
        loadAssignments(courseCode);

        setButtonListeners(courseCode, courseName, instructorName);
    }

    private void initUI() {
        courseCodeTextView = findViewById(R.id.tvCourseCode);
        courseNameTextView = findViewById(R.id.tvCourseName);
        instructorNameTextView = findViewById(R.id.tvInstructor);

        studentListTextView = findViewById(R.id.txStudentList);
        btnAssignmentUpload = findViewById(R.id.Assbutton);
        btnMaterialUpload = findViewById(R.id.Matbutton);

        materialRecyclerView = findViewById(R.id.matRecyclerView);
        materialRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        assignmentRecyclerView = findViewById(R.id.assigmentRV);
        assignmentRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        resourceList = new ArrayList<>();
        resourceAdapter = new ResourceAdapter(resourceList);
        materialRecyclerView.setAdapter(resourceAdapter);

        assignmentList = new ArrayList<>();
        assignmentAdapter = new AssignmentAdapter(assignmentList, this);
        assignmentRecyclerView.setAdapter(assignmentAdapter);
    }

    private void setButtonListeners(String courseCode, String courseName, String instructorName) {
        btnAssignmentUpload.setOnClickListener(v -> {
            Intent intent = new Intent(InstructorDashboardActivity.this, AssignmentUploadActivity.class);
            intent.putExtra("course_code", courseCode);
            intent.putExtra("course_name", courseName);
            intent.putExtra("instructor_name", instructorName);
            startActivity(intent);
        });

        btnMaterialUpload.setOnClickListener(v -> {
            Intent intent = new Intent(InstructorDashboardActivity.this, MaterialUploadActivity.class);
            intent.putExtra("course_code", courseCode);
            intent.putExtra("course_name", courseName);
            intent.putExtra("instructor_name", instructorName);
            startActivity(intent);
        });

        studentListTextView.setOnClickListener(v -> {
            Intent intent = new Intent(InstructorDashboardActivity.this, StudentListActivity.class);
            intent.putExtra("course_code", courseCode);
            startActivity(intent);
        });
    }

    private void loadTeachingResources(String courseCode) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                MysqlConnect mysqlConnect = new MysqlConnect();
                Connection conn = mysqlConnect.CONN();

                if (conn != null) {
                    // 查询课程 ID
                    String courseQuery = "SELECT id FROM courses WHERE course_code = ?";
                    PreparedStatement courseStmt = conn.prepareStatement(courseQuery);
                    courseStmt.setString(1, courseCode);

                    ResultSet courseRs = courseStmt.executeQuery();
                    int courseId = -1;

                    if (courseRs.next()) {
                        courseId = courseRs.getInt("id");
                    }

                    courseRs.close();
                    courseStmt.close();

                    if (courseId == -1) {
                        runOnUiThread(() -> Toast.makeText(this, "Course not found", Toast.LENGTH_SHORT).show());
                        return;
                    }

                    // 查询教学资源
                    String resourceQuery = "SELECT r.title, u.name AS instructor_name, r.created_at " +
                            "FROM teaching_resources r " +
                            "JOIN users u ON r.instructor_id = u.id " +
                            "WHERE r.course_id = ?";
                    PreparedStatement resourceStmt = conn.prepareStatement(resourceQuery);
                    resourceStmt.setInt(1, courseId);

                    ResultSet resourceRs = resourceStmt.executeQuery();
                    resourceList.clear();

                    while (resourceRs.next()) {
                        String title = resourceRs.getString("title");
                        String instructorName = resourceRs.getString("instructor_name");
                        String createdAt = resourceRs.getString("created_at");

                        // 添加到资源列表
                        resourceList.add(new ResourceModel(title, instructorName, createdAt));
                    }

                    resourceRs.close();
                    resourceStmt.close();
                    conn.close();

                    // 更新 UI
                    runOnUiThread(() -> resourceAdapter.notifyDataSetChanged());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Failed to load teaching resources", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void loadAssignments(String courseCode) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                MysqlConnect mysqlConnect = new MysqlConnect();
                Connection conn = mysqlConnect.CONN();

                if (conn != null) {
                    // 查询课程 ID
                    String courseQuery = "SELECT id FROM courses WHERE course_code = ?";
                    PreparedStatement courseStmt = conn.prepareStatement(courseQuery);
                    courseStmt.setString(1, courseCode);

                    ResultSet courseRs = courseStmt.executeQuery();
                    int courseId = -1;

                    if (courseRs.next()) {
                        courseId = courseRs.getInt("id");
                    }

                    courseRs.close();
                    courseStmt.close();

                    if (courseId == -1) {
                        runOnUiThread(() -> Toast.makeText(this, "Course not found", Toast.LENGTH_SHORT).show());
                        return;
                    }

                    // 查询作业列表，同时获取 Assignment ID
                    String assignmentQuery =
                            "SELECT a.id, a.title, a.due_date, u.name AS creator " +
                                    "FROM assignments a " +
                                    "JOIN users u ON a.creator_id = u.id " + // 使用正确的字段名 creator_id
                                    "WHERE a.course_id = ?";
                    PreparedStatement assignmentStmt = conn.prepareStatement(assignmentQuery);
                    assignmentStmt.setInt(1, courseId);

                    ResultSet assignmentRs = assignmentStmt.executeQuery();
                    assignmentList.clear();

                    while (assignmentRs.next()) {
                        int id = assignmentRs.getInt("id"); // 获取 Assignment ID
                        String title = assignmentRs.getString("title");
                        String dueDate = assignmentRs.getString("due_date");
                        String creator = assignmentRs.getString("creator"); // 获取 Creator

                        // 将 Assignment ID 和其他字段添加到列表
                        assignmentList.add(new AssignmentModel(id, title, creator, dueDate));
                    }

                    assignmentRs.close();
                    assignmentStmt.close();
                    conn.close();

                    // 更新 UI
                    runOnUiThread(() -> assignmentAdapter.notifyDataSetChanged());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Failed to load assignments", Toast.LENGTH_SHORT).show());
            }
        });
    }
}