package com.example.edusync.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Domain.MyCourseDomain;
import com.example.edusync.R;

import java.util.ArrayList;

public class MyCourseAdapter extends RecyclerView.Adapter<MyCourseAdapter.ViewHolder> {

    private ArrayList<MyCourseDomain> courses;
    private OnItemClickListener listener;

    public MyCourseAdapter(ArrayList<MyCourseDomain> courses, OnItemClickListener listener) {
        this.courses = courses;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onImageClick(MyCourseDomain course);  // 点击课程代码的事件
        void onTitleClick(MyCourseDomain course); // 点击课程标题的事件
        void onCourseClick(MyCourseDomain course); // 点击整个课程项的事件
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_my_course, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MyCourseDomain course = courses.get(position);

        // 设置课程信息
        holder.courseCode.setText(course.getCourseCode()); // 使用 getCourseCode()
        holder.courseName.setText(course.getTitle());
        holder.instructorName.setText(course.getOwner());

        // 设置点击事件
        holder.courseCode.setOnClickListener(v -> listener.onImageClick(course));    // 点击课程代码
        holder.courseName.setOnClickListener(v -> listener.onTitleClick(course));   // 点击课程标题
        holder.itemView.setOnClickListener(v -> listener.onCourseClick(course));    // 点击整个课程项
    }

    @Override
    public int getItemCount() {
        return courses.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView courseCode, courseName, instructorName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            courseCode = itemView.findViewById(R.id.course_code);
            courseName = itemView.findViewById(R.id.course_name);
            instructorName = itemView.findViewById(R.id.ownerText);
        }
    }
}