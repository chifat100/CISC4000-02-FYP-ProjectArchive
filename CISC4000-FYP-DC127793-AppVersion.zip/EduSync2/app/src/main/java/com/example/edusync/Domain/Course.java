package com.example.edusync.Domain;

public class Course {
    private int id;
    private String courseCode;
    private String courseName;
    private String description;
    private int instructorId; // 新增字段，存储导师 ID
    private String instructorName; // 新增字段，存储导师名称

    public Course(int id, String courseCode, String courseName, String description, int instructorId, String instructorName) {
        this.id = id;
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.description = description;
        this.instructorId = instructorId;
        this.instructorName = instructorName;
    }

    public int getId() { return id; }
    public String getCourseCode() { return courseCode; }
    public String getCourseName() { return courseName; }
    public String getDescription() { return description; }
    public int getInstructorId() { return instructorId; }
    public String getInstructorName() { return instructorName; }
}