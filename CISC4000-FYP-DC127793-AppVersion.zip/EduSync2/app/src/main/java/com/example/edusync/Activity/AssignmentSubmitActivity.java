package com.example.edusync.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.edusync.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AssignmentSubmitActivity extends AppCompatActivity {

    private static final int FILE_SELECT_CODE = 1;

    // UI 元素
    private TextView assignmentTitleTextView, assignmentCreatorTextView, assignmentDueDateTextView;
    private TextView maxScoreTextView, filePathTextView, gradeTextView;
    private Button selectFileButton, submitFileButton;

    // 数据
    private int studentId = -1;          // 从 SharedPreferences 中获取的 student_id
    private int assignmentId = -1;      // 从数据库中获取的 assignment_id
    private String fileTitle = null;    // 文件标题
    private File selectedFile = null;   // 选中的文件

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_submit);

        // 初始化 UI 元素
        assignmentTitleTextView = findViewById(R.id.tvAssignmentTitle);
        assignmentCreatorTextView = findViewById(R.id.tvAssignmentCreator);
        assignmentDueDateTextView = findViewById(R.id.tvAssignmentDueDate);
        filePathTextView = findViewById(R.id.fileTextView);
        gradeTextView = findViewById(R.id.textViewGrade);
        maxScoreTextView = findViewById(R.id.tvHighestScore);
        selectFileButton = findViewById(R.id.selectFileButton);
        submitFileButton = findViewById(R.id.submitFileButton);

        // 从 Intent 获取作业信息
        String title = getIntent().getStringExtra("assignment_title");
        String creator = getIntent().getStringExtra("assignment_creator");
        String dueDate = getIntent().getStringExtra("assignment_due_date");

        // 显示作业信息
        assignmentTitleTextView.setText(title);
        assignmentCreatorTextView.setText("Created by: " + creator);
        assignmentDueDateTextView.setText("Due Date: " + dueDate);

        // 从数据库获取 `assignment_id`
        fetchAssignmentId(title);

        // 获取 student_id
        studentId = getStudentId();
        if (studentId == -1) {
            Toast.makeText(this, "Student ID not found in SharedPreferences", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 初始化文件选择功能
        selectFileButton.setOnClickListener(v -> openFileChooser());

        // 提交文件到数据库
        submitFileButton.setOnClickListener(v -> {
            if (validateInputs() && assignmentId != -1 && studentId != -1) {
                submitAssignmentToDatabase();
            } else {
                Toast.makeText(this, "Please select a file and try again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 获取 student_id
    private int getStudentId() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE); // 确保文件名与登录时一致
        return sharedPreferences.getInt("user_id", -1); // 确保键名与登录时一致
    }
    private void fetchFeedback(int assignmentId, int studentId) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 查询 feedback
                    String query = "SELECT feedback FROM assignment_submissions WHERE assignment_id = ? AND student_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, assignmentId);
                    stmt.setInt(2, studentId);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        String feedback = rs.getString("feedback");

                        // 更新 UI
                        runOnUiThread(() -> {
                            TextView feedbackTextView = findViewById(R.id.FeedbackText);
                            if (feedback != null && !feedback.isEmpty()) {
                                feedbackTextView.setText(feedback); // 显示反馈内容
                            } else {
                                feedbackTextView.setText("No feedback available"); // 显示默认值
                            }
                        });
                    } else {
                        // 如果没有记录
                        runOnUiThread(() -> {
                            TextView feedbackTextView = findViewById(R.id.FeedbackText);
                            feedbackTextView.setText("No feedback available"); // 显示默认值
                        });
                    }

                    rs.close();
                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error fetching feedback: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
    private void fetchGrade(int assignmentId, int studentId) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 查询 grade
                    String query = "SELECT grade FROM assignment_submissions WHERE assignment_id = ? AND student_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, assignmentId);
                    stmt.setInt(2, studentId);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        int grade = rs.getInt("grade");

                        // 更新 UI
                        runOnUiThread(() -> {
                            gradeTextView.setText(String.valueOf(grade)); // 将整数转换为字符串
                        });
                    } else {
                        // 如果没有 grade 记录
                        runOnUiThread(() -> {
                            gradeTextView.setText("None"); // 显示默认值
                        });
                    }

                    rs.close();
                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error fetching grade: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
    private void fetchMaxScore(int assignmentId) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 查询 max_score
                    String query = "SELECT max_score FROM assignments WHERE id = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, assignmentId);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        int maxScore = rs.getInt("max_score");

                        // 更新 UI
                        runOnUiThread(() -> {
                            maxScoreTextView.setText("/" + maxScore);
                        });
                    } else {
                        // 如果没有 max_score 记录
                        runOnUiThread(() -> {
                            maxScoreTextView.setText("");
                        });
                    }

                    rs.close();
                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error fetching max score: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    // 打开文件选择器
    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "Select a file"), FILE_SELECT_CODE);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening file chooser", Toast.LENGTH_SHORT).show();
        }
    }

    // 处理文件选择结果
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedFileUri = data.getData();

            // 获取文件名并设置为标题
            fileTitle = getFileName(selectedFileUri);
            filePathTextView.setText(fileTitle);

            // 复制文件到应用缓存目录
            selectedFile = copyFileToCache(selectedFileUri, fileTitle);
        }
    }

    // 获取文件名
    private String getFileName(Uri uri) {
        String fileName = "Unknown File";
        try {
            if (uri.getScheme().equals("content")) {
                try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        fileName = cursor.getString(nameIndex);
                    }
                }
            } else if (uri.getScheme().equals("file")) {
                fileName = new File(uri.getPath()).getName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileName;
    }

    // 复制文件到缓存
    private File copyFileToCache(Uri uri, String fileName) {
        try {
            File cacheFile = new File(getCacheDir(), fileName);
            try (InputStream inputStream = getContentResolver().openInputStream(uri);
                 FileOutputStream outputStream = new FileOutputStream(cacheFile)) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }
            }
            return cacheFile;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error copying file", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    // 验证输入
    private boolean validateInputs() {
        return selectedFile != null;
    }

    // 提交作业到数据库
    private void submitAssignmentToDatabase() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 查询作业的 due_date
                    String queryDueDateSql = "SELECT due_date FROM assignments WHERE id = ?";
                    PreparedStatement queryStmt = conn.prepareStatement(queryDueDateSql);
                    queryStmt.setInt(1, assignmentId);

                    ResultSet resultSet = queryStmt.executeQuery();
                    String status;

                    if (resultSet.next()) {
                        // 获取作业的 due_date
                        java.sql.Timestamp dueDate = resultSet.getTimestamp("due_date");

                        // 获取当前时间
                        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(System.currentTimeMillis());

                        // 比较当前时间和 due_date，确定 status
                        if (currentTimestamp.after(dueDate)) {
                            status = "late"; // 超过 due_date，状态为 late
                        } else {
                            status = "submitted"; // 未超过 due_date，状态为 submitted
                        }

                        resultSet.close();
                        queryStmt.close();

                        // 插入作业提交记录
                        String insertSql = "INSERT INTO assignment_submissions (assignment_id, student_id, title, file_path, submission_date, status) " +
                                "VALUES (?, ?, ?, ?, NOW(), ?)";
                        PreparedStatement insertStmt = conn.prepareStatement(insertSql);

                        // 设置占位符参数
                        insertStmt.setInt(1, assignmentId); // 作业 ID
                        insertStmt.setInt(2, studentId); // 学生 ID
                        insertStmt.setString(3, selectedFile != null ? selectedFile.getName() : "Untitled"); // 文件标题
                        insertStmt.setString(4, selectedFile != null ? selectedFile.getAbsolutePath() : null); // 文件路径
                        insertStmt.setString(5, status); // 状态

                        int rowsInserted = insertStmt.executeUpdate();
                        insertStmt.close();

                        // 更新 UI
                        runOnUiThread(() -> {
                            if (rowsInserted > 0) {
                                Toast.makeText(this, "Assignment submitted successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(this, "Failed to submit assignment", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "Invalid assignment ID", Toast.LENGTH_SHORT).show());
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    // 从数据库获取 assignment_id
    private void fetchAssignmentId(String assignmentTitle) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    String query = "SELECT id FROM assignments WHERE title = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, assignmentTitle);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        assignmentId = rs.getInt("id");
                        // 获取最高分
                        fetchMaxScore(assignmentId); // 在这里调用
                        // 获取 grade
                        fetchGrade(assignmentId, studentId);
                        fetchFeedback(assignmentId, studentId);// 使用 assignmentId 和 studentId 查询 grade
                    }

                    rs.close();
                    stmt.close();
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error fetching assignment ID: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (selectedFile != null && selectedFile.exists()) {
            selectedFile.delete();
        }
    }
}