package com.example.edusync.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.edusync.Adapter.SubmissionAdapter;
import com.example.edusync.Domain.Submission;
import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AssignmentGradingActivity extends AppCompatActivity {

    private TextView assignmentTitleTextView, assignmentCreatorTextView, assignmentDueDateTextView;
    private RecyclerView submissionsRecyclerView;
    private SubmissionAdapter submissionAdapter;
    private List<Submission> submissionList;

    private int assignmentId = -1; // assignmentId 从 Intent 传递过来

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_grading);

        // 初始化视图
        assignmentTitleTextView = findViewById(R.id.tvAssignmentTitle);
        assignmentCreatorTextView = findViewById(R.id.tvAssignmentCreator);
        assignmentDueDateTextView = findViewById(R.id.tvAssignmentDueDate);
        submissionsRecyclerView = findViewById(R.id.submissionsRecyclerView);

        // 从 Intent 获取数据
        String title = getIntent().getStringExtra("assignment_title");
        String creator = getIntent().getStringExtra("assignment_creator");
        String dueDate = getIntent().getStringExtra("assignment_due_date");
        assignmentId = getIntent().getIntExtra("assignment_id", -1);

        if (assignmentId == -1) {
            Toast.makeText(this, "Assignment ID not found", Toast.LENGTH_SHORT).show();
            return; // 终止执行
        }

        // 显示作业信息
        assignmentTitleTextView.setText(title);
        assignmentCreatorTextView.setText("Created by: " + creator);
        assignmentDueDateTextView.setText("Due Date: " + dueDate);

        // 初始化 RecyclerView
        submissionList = new ArrayList<>();
        submissionAdapter = new SubmissionAdapter(submissionList, submission -> {
            // 点击事件逻辑：跳转到 SubmissionDetailActivity
            Intent intent = new Intent(this, SubmissionDetailActivity.class);
            intent.putExtra("student_name", submission.getStudentName());
            intent.putExtra("file_name", submission.getFileName());
            intent.putExtra("status", submission.getStatus());
            intent.putExtra("grade", submission.getGrade());
            intent.putExtra("submission_time", submission.getSubmissionTime());
            intent.putExtra("assignment_id", assignmentId);
            startActivity(intent);
        });
        submissionsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        submissionsRecyclerView.setAdapter(submissionAdapter);

        // 加载提交数据
        fetchSubmissions();
    }

    private void fetchSubmissions() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 查询作业提交情况
                    String query = "SELECT users.name AS student_name, " +
                            "assignment_submissions.title AS file_name, " + // 使用 title 作为 file_name
                            "assignment_submissions.status, " +
                            "assignment_submissions.grade, " +
                            "assignment_submissions.submission_date " +
                            "FROM assignment_submissions " +
                            "INNER JOIN users ON assignment_submissions.student_id = users.id " +
                            "WHERE assignment_submissions.assignment_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, assignmentId);

                    ResultSet rs = stmt.executeQuery();
                    while (rs.next()) {
                        String studentName = rs.getString("student_name");
                        String fileName = rs.getString("file_name"); // 这里是 title 别名
                        String status = rs.getString("status");
                        String grade = rs.getString("grade") != null ? rs.getString("grade") : "--";
                        String submissionTime = rs.getString("submission_date");

                        // 添加到列表
                        submissionList.add(new Submission(studentName, fileName, status, grade, submissionTime));
                    }

                    rs.close();
                    stmt.close();

                    // 更新 RecyclerView
                    runOnUiThread(() -> submissionAdapter.notifyDataSetChanged());
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Failed to connect to database", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error fetching submissions: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}