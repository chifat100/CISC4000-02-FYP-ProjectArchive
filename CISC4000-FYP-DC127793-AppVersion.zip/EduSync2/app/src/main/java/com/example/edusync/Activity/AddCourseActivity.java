package com.example.edusync.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;

import com.example.edusync.Domain.Course;
import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddCourseActivity extends AppCompatActivity {

    private EditText etSearch; // 搜索栏
    private RecyclerView recyclerView; // RecyclerView
    private com.example.edusync.Activity.CourseAdapter2 courseAdapter; // 自定义适配器
    private ArrayList<Course> courseList; // 数据源
    private MysqlConnect mySQLConnect; // 数据库连接

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);

        // 初始化组件
        etSearch = findViewById(R.id.editTextText);
        recyclerView = findViewById(R.id.recyclerView);

        // 初始化 RecyclerView
        courseList = new ArrayList<>();
        courseAdapter = new com.example.edusync.Activity.CourseAdapter2(courseList, course -> {
            // 点击课程时跳转到 AddCourseActivity2，并传递课程信息
            Intent intent = new Intent(AddCourseActivity.this, AddCourseActivity2.class);
            intent.putExtra("course_id", course.getId()); // 传递课程 ID
            intent.putExtra("course_code", course.getCourseCode());
            intent.putExtra("course_name", course.getCourseName());
            intent.putExtra("description", course.getDescription());
            intent.putExtra("instructor_name", course.getInstructorName());
            startActivity(intent);
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(courseAdapter);

        // 初始化数据库连接
        mySQLConnect = new MysqlConnect();

        // 添加搜索栏监听器
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 实时搜索
                searchCourses(s.toString().trim());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    /**
     * 搜索课程
     */
    private void searchCourses(String keyword) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = mySQLConnect.CONN()) {
                if (conn != null) {
                    // 查询 courses 表，获取课程信息
                    String courseQuery = "SELECT id, course_code, course_name, description, instructor_id FROM courses WHERE course_code LIKE ? OR course_name LIKE ?";
                    PreparedStatement courseStmt = conn.prepareStatement(courseQuery);
                    String searchKeyword = "%" + keyword + "%";
                    courseStmt.setString(1, searchKeyword);
                    courseStmt.setString(2, searchKeyword);

                    ResultSet courseResultSet = courseStmt.executeQuery();
                    ArrayList<Course> tempList = new ArrayList<>();

                    while (courseResultSet.next()) {
                        int courseId = courseResultSet.getInt("id");
                        String courseCode = courseResultSet.getString("course_code");
                        String courseName = courseResultSet.getString("course_name");
                        String description = courseResultSet.getString("description");
                        int instructorId = courseResultSet.getInt("instructor_id");

                        // 查询 users 表，根据 instructor_id 获取导师名称
                        String instructorQuery = "SELECT name FROM users WHERE id = ?";
                        PreparedStatement instructorStmt = conn.prepareStatement(instructorQuery);
                        instructorStmt.setInt(1, instructorId);

                        ResultSet instructorResultSet = instructorStmt.executeQuery();
                        String instructorName = "";
                        if (instructorResultSet.next()) {
                            instructorName = instructorResultSet.getString("name");
                        }

                        // 创建 Course 对象
                        tempList.add(new Course(courseId, courseCode, courseName, description, instructorId, instructorName));

                        instructorResultSet.close();
                        instructorStmt.close();
                    }

                    // 更新 UI
                    runOnUiThread(() -> {
                        courseList.clear();
                        courseList.addAll(tempList);
                        courseAdapter.notifyDataSetChanged(); // 通知适配器数据已更改
                    });

                    courseResultSet.close();
                    courseStmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "数据库连接失败", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "发生错误：" + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}