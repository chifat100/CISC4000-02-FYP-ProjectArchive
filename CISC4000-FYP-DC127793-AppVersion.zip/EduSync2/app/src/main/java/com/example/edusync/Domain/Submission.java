package com.example.edusync.Domain;

public class Submission {

    private String studentName;
    private String fileName;
    private String status;
    private String grade;
    private String submissionTime;

    public Submission(String studentName, String fileName, String status, String grade, String submissionTime) {
        this.studentName = studentName;
        this.fileName = fileName;
        this.status = status;
        this.grade = grade;
        this.submissionTime = submissionTime;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getFileName() {
        return fileName;
    }

    public String getStatus() {
        return status;
    }

    public String getGrade() {
        return grade;
    }

    public String getSubmissionTime() {
        return submissionTime;
    }
}