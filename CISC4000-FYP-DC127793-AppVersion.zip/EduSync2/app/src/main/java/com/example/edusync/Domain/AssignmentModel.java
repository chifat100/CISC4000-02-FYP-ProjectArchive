package com.example.edusync.Domain;

public class AssignmentModel {
    private int id;
    private String title;
    private String creator; // 添加 Creator 字段
    private String dueDate;

    public AssignmentModel(int id,String title, String creator, String dueDate) {
        this.id = id;
        this.title = title;
        this.creator = creator;
        this.dueDate = dueDate;
    }

    public int getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }

    public String getCreator() {
        return creator;
    }

    public String getDueDate() {
        return dueDate;
    }
}