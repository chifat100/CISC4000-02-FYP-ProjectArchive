package com.example.edusync.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Adapter.MyCourseAdapter;
import com.example.edusync.Domain.MyCourseDomain;
import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class StudentCourseActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MyCourseAdapter adapter;
    private MysqlConnect mySQLConnect;
    private Button btnAddCourse; // 声明按钮

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_student);

        recyclerView = findViewById(R.id.MyCourseView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        btnAddCourse = findViewById(R.id.btn_add_course); // 初始化按钮

        mySQLConnect = new MysqlConnect();

        // 动态加载用户注册的课程
        loadUserCourses();

        // 设置按钮点击事件
        btnAddCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddCourseActivity();
            }
        });
    }

    /**
     * 跳转到 AddCourseActivity
     */
    private void openAddCourseActivity() {
        Intent intent = new Intent(StudentCourseActivity.this, AddCourseActivity.class);

        // 如果需要传递用户 ID，可以从 SharedPreferences 获取并传递
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int userId = sharedPreferences.getInt("instructor_id", -1);
        if (userId != -1) {
            intent.putExtra("user_id", userId); // 传递用户 ID
        }

        startActivity(intent);
    }

    /**
     * 从数据库加载用户注册的课程
     */
    private void loadUserCourses() {
        // 从 SharedPreferences 获取 user_id (作为 student_id)
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int studentId = sharedPreferences.getInt("user_id", -1); // 获取 student_id

        if (studentId == -1) {
            Toast.makeText(this, "用户未登录，请先登录", Toast.LENGTH_SHORT).show();
            return;
        }

        // 创建线程池来进行数据库查询
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            ArrayList<MyCourseDomain> courses = new ArrayList<>();
            try (Connection conn = mySQLConnect.CONN()) {
                if (conn != null) {
                    // SQL 查询语句：通过 student_id 查询学生注册的课程
                    String query = "SELECT c.course_code, c.course_name, u.name AS instructor " +
                            "FROM enrollments e " +
                            "JOIN courses c ON e.course_id = c.id " +
                            "JOIN users u ON c.instructor_id = u.id " +
                            "WHERE e.student_id = ? AND e.status = 'active'";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, studentId); // 设置 student_id 参数

                    ResultSet rs = stmt.executeQuery();
                    while (rs.next()) {
                        // 从查询结果中获取课程信息
                        String courseCode = rs.getString("course_code");
                        String courseName = rs.getString("course_name");
                        String instructorName = rs.getString("instructor");

                        // 创建课程对象并添加到列表
                        courses.add(new MyCourseDomain(courseName, instructorName, 0.0, 0.0, courseCode));
                    }

                    rs.close();
                    stmt.close();
                }

                // 更新 UI
                runOnUiThread(() -> {
                    if (!courses.isEmpty()) {
                        // 初始化适配器并设置 RecyclerView
                        adapter = new MyCourseAdapter(courses, new MyCourseAdapter.OnItemClickListener() {
                            @Override
                            public void onImageClick(MyCourseDomain course) {
                                Toast.makeText(StudentCourseActivity.this, "点击了课程代码：" + course.getCourseCode(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onTitleClick(MyCourseDomain course) {
                                Toast.makeText(StudentCourseActivity.this, "点击了课程标题：" + course.getTitle(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCourseClick(MyCourseDomain course) {
                                // 跳转到 StudentDashboardActivity
                                Intent intent = new Intent(StudentCourseActivity.this, StudentDashboardActivity.class);
                                intent.putExtra("course_code", course.getCourseCode());
                                intent.putExtra("course_name", course.getTitle());
                                intent.putExtra("instructor_name", course.getOwner());
                                startActivity(intent);
                            }
                        });
                        recyclerView.setAdapter(adapter);
                    } else {
                        Toast.makeText(StudentCourseActivity.this, "没有找到任何课程", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                Log.e("StudentCourseActivity", "加载课程时发生错误：" + e.getMessage());
                runOnUiThread(() -> Toast.makeText(StudentCourseActivity.this, "加载课程失败：" + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}