package com.example.edusync.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.edusync.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MaterialUploadActivity extends AppCompatActivity {

    private static final int FILE_SELECT_CODE = 1; // 请求码，用于识别文件选择器的结果
    private TextView filePathTextView; // 显示选中文件的路径或名称的 TextView
    private EditText descriptionEditText; // 输入 description 的 EditText
    private Button uploadFileButton; // 上传文件按钮
    private Uri selectedFileUri = null; // 选中文件的 Uri
    private File selectedFile = null; // 选中文件的缓存副本
    private String fileType = null; // 文件类型

    private String courseCode; // 课程代码
    private int courseId = -1; // 课程 ID
    private int instructorId = -1; // 教师 ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material_upload);

        filePathTextView = findViewById(R.id.MaterialTextView);
        descriptionEditText = findViewById(R.id.editTextDes); // 初始化 EditText
        Button selectFileButton = findViewById(R.id.selectFileButton);
        uploadFileButton = findViewById(R.id.uploadFileButton);

        // 从 Intent 获取传递的 course_code
        Intent intent = getIntent();
        courseCode = intent.getStringExtra("course_code");

        if (courseCode == null || courseCode.isEmpty()) {
            Toast.makeText(this, "Invalid course code", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 从 SharedPreferences 获取 instructor_id
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        instructorId = sharedPreferences.getInt("user_id", -1); // 使用一致的键名 "user_id"

        if (instructorId == -1) {
            Toast.makeText(this, "Instructor ID not found. Please log in.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 获取 course_id
        fetchCourseId();

        // 文件选择按钮逻辑
        selectFileButton.setOnClickListener(v -> openFileChooser());

        // 文件上传按钮逻辑
        uploadFileButton.setOnClickListener(v -> {
            if (selectedFile != null && courseId != -1) {
                saveToDatabase(selectedFile); // 保存到数据库
            } else if (courseId == -1) {
                Toast.makeText(this, "Course ID not available yet", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 从数据库获取 course_id
    private void fetchCourseId() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    String query = "SELECT id AS course_id FROM courses WHERE course_code = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, courseCode);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        int courseId = rs.getInt("course_id");

                        runOnUiThread(() -> {
                            Toast.makeText(MaterialUploadActivity.this, "Course ID fetched: " + courseId, Toast.LENGTH_SHORT).show();
                            MaterialUploadActivity.this.courseId = courseId;
                        });
                    } else {
                        runOnUiThread(() -> Toast.makeText(MaterialUploadActivity.this, "Course code not found in database", Toast.LENGTH_SHORT).show());
                    }

                    rs.close();
                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(MaterialUploadActivity.this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MaterialUploadActivity.this, "Error fetching course ID: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    // 打开文件选择器
    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // 允许所有文件类型
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "Select a file"), FILE_SELECT_CODE);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening file chooser", Toast.LENGTH_SHORT).show();
        }
    }

    // 处理文件选择器的结果
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            selectedFileUri = data.getData();

            // 获取文件名并显示
            String fileName = getFileName(selectedFileUri);
            filePathTextView.setText(fileName);

            // 获取文件类型
            fileType = getFileMimeType(selectedFileUri);

            // 将文件复制到应用的缓存目录中
            selectedFile = copyFileToCache(selectedFileUri, fileName);

            // 如果文件成功复制，启用上传按钮
            uploadFileButton.setEnabled(selectedFile != null);
        }
    }

    // 从 Uri 获取文件名
    private String getFileName(Uri uri) {
        String fileName = "Unknown File";
        try {
            if ("content".equals(uri.getScheme())) {
                try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        fileName = cursor.getString(nameIndex);
                    }
                }
            } else if ("file".equals(uri.getScheme())) {
                fileName = new File(uri.getPath()).getName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileName;
    }

    // 获取文件的 MIME 类型
    private String getFileMimeType(Uri uri) {
        String mimeType = null;
        if (uri.getScheme().equals("content")) {
            mimeType = getContentResolver().getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri.toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension);
        }
        return mimeType != null ? mimeType : "unknown";
    }

    // 将文件复制到应用缓存目录中
    private File copyFileToCache(Uri uri, String fileName) {
        try {
            File cacheFile = new File(getCacheDir(), fileName);
            try (InputStream inputStream = getContentResolver().openInputStream(uri);
                 FileOutputStream outputStream = new FileOutputStream(cacheFile)) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }
            }
            return cacheFile;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error copying file", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    // 保存文件信息到数据库
    private void saveToDatabase(File file) {
        String description = descriptionEditText.getText().toString().trim(); // 获取用户输入的描述内容

        if (description.isEmpty()) {
            Toast.makeText(this, "Description cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 检查是否存在同名文件和路径
                    String checkQuery = "SELECT COUNT(*) AS file_count FROM teaching_resources WHERE file_path = ? AND title = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkQuery);

                    checkStmt.setString(1, file.getAbsolutePath()); // 文件路径
                    checkStmt.setString(2, file.getName()); // 文件名

                    ResultSet rs = checkStmt.executeQuery();
                    if (rs.next() && rs.getInt("file_count") > 0) {
                        // 如果文件已存在，提示用户
                        runOnUiThread(() -> Toast.makeText(MaterialUploadActivity.this, "File with the same name and path already exists", Toast.LENGTH_SHORT).show());
                        rs.close();
                        checkStmt.close();
                        return;
                    }

                    rs.close();
                    checkStmt.close();

                    // 插入到 teaching_resources 表
                    String query = "INSERT INTO teaching_resources (instructor_id, course_id, title, description, file_path, type, created_at) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(query);

                    stmt.setInt(1, instructorId);
                    stmt.setInt(2, courseId);
                    stmt.setString(3, file.getName()); // 文件名作为标题
                    stmt.setString(4, description); // 用户输入的描述内容
                    stmt.setString(5, file.getAbsolutePath()); // 文件路径
                    stmt.setString(6, fileType); // 文件 MIME 类型
                    stmt.setTimestamp(7, new Timestamp(System.currentTimeMillis())); // 当前时间戳

                    int rowsInserted = stmt.executeUpdate();

                    runOnUiThread(() -> {
                        if (rowsInserted > 0) {
                            Toast.makeText(MaterialUploadActivity.this, "Upload successful", Toast.LENGTH_SHORT).show();
                            // 返回到 InstructorDashboardActivity
                            Intent intent = new Intent(MaterialUploadActivity.this, InstructorDashboardActivity.class);
                            intent.putExtra("status", "success");
                            intent.putExtra("fileName", file.getName());
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(MaterialUploadActivity.this, "Failed to save file information", Toast.LENGTH_SHORT).show();
                        }
                    });

                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(MaterialUploadActivity.this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MaterialUploadActivity.this, "Error saving to database: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}