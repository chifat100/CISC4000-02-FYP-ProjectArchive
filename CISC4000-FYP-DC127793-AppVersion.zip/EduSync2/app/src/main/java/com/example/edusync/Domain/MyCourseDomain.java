package com.example.edusync.Domain;

public class MyCourseDomain {
    private String id;
    private String title;       // 课程名称
    private String owner;       // 导师名称
    private double price;       // 价格
    private double rating;      // 评分
    private String courseCode;  // 课程代码

    // 构造函数
    public MyCourseDomain(String title, String owner, double price, double rating, String courseCode) {
        this.id=id;
        this.title = title;
        this.owner = owner;
        this.price = price;
        this.rating = rating;
        this.courseCode = courseCode;
    }

    // Getter 方法
    public String getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }

    public String getOwner() {
        return owner;
    }

    public double getPrice() {
        return price;
    }

    public double getRating() {
        return rating;
    }

    public String getCourseCode() { // 获取课程代码的方法
        return courseCode;
    }
}