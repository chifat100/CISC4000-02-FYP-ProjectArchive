package com.example.edusync.Activity;

import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MysqlConnect{

    // MySQL 服務器的配置信息
    private static final String DB_URL = "jdbc:mysql://10.0.2.2:3306/testbed03"; // MySQL 的 JDBC URL
    private static final String DB_USER = "song"; // MySQL 用戶名
    private static final String DB_PASSWORD = "771230"; // MySQL 密碼

    public Connection CONN() {
        Connection conn = null;
        try {
            // 啟用主線程的網絡操作（僅用於測試，生產環境請使用異步操作）
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            // 加載 MySQL 驅動
            Class.forName("com.mysql.jdbc.Driver");

            // 建立連接
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            Log.d("MySQLConnection", "Connection successful!");
        } catch (ClassNotFoundException e) {
            Log.e("MySQLConnection", "MySQL Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            Log.e("MySQLConnection", "Connection failed: " + e.getMessage());
        } catch (Exception e) {
            Log.e("MySQLConnection", "Unexpected error: " + e.getMessage());
        }
        return conn;
    }
}