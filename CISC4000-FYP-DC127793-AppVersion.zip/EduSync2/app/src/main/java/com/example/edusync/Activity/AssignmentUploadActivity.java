package com.example.edusync.Activity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.edusync.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AssignmentUploadActivity extends AppCompatActivity {

    private static final int FILE_SELECT_CODE = 1;
    private EditText deadlineEditText, descriptionEditText, maxScoreEditText;
    private TextView filePathTextView;
    private Button saveAssignmentButton, selectFileButton;
    private Uri selectedFileUri = null;
    private File selectedFile = null;

    private String courseCode; // 从 Intent 获取的课程代码
    private int courseId = -1; // 从数据库获取的 course_id
    private String dueDate; // 用户选择的截止日期
    private String fileTitle; // 用于保存文件名作为标题

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment_upload);

        // 初始化视图
        deadlineEditText = findViewById(R.id.deadlineEditText);
        descriptionEditText = findViewById(R.id.DescriptionText);
        maxScoreEditText = findViewById(R.id.MaxScoretext); // 假设在 XML 中设置了这个 ID
        filePathTextView = findViewById(R.id.AssignmentTextView);
        selectFileButton = findViewById(R.id.selectFileButton);
        saveAssignmentButton = findViewById(R.id.uploadFileButton);

        // 从 Intent 获取课程代码
        courseCode = getIntent().getStringExtra("course_code");

        // 检查课程代码是否有效
        if (courseCode == null || courseCode.isEmpty()) {
            Toast.makeText(this, "Invalid course code", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 从数据库获取 course_id
        fetchCourseId();

        // 初始化日期和时间选择功能
        deadlineEditText.setOnClickListener(v -> showDateTimePicker());

        // 初始化文件选择功能
        selectFileButton.setOnClickListener(v -> openFileChooser());

        // 保存作业信息到数据库
        saveAssignmentButton.setOnClickListener(v -> {
            if (validateInputs() && courseId != -1) {
                saveAssignmentToDatabase();
            } else {
                Toast.makeText(this, "Please select a file and fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 日期和时间选择器
    private void showDateTimePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;

                    TimePickerDialog timePickerDialog = new TimePickerDialog(
                            this,
                            (timeView, selectedHour, selectedMinute) -> {
                                String selectedTime = String.format("%02d:%02d", selectedHour, selectedMinute);
                                dueDate = selectedDate + " " + selectedTime;
                                deadlineEditText.setText(dueDate);
                            },
                            calendar.get(Calendar.HOUR_OF_DAY),
                            calendar.get(Calendar.MINUTE),
                            true
                    );

                    timePickerDialog.show();
                },
                year, month, day
        );

        datePickerDialog.show();
    }

    // 打开文件选择器
    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "Select a file"), FILE_SELECT_CODE);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening file chooser", Toast.LENGTH_SHORT).show();
        }
    }

    // 处理文件选择结果
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK && data != null) {
            selectedFileUri = data.getData();

            // 获取文件名并设置为标题
            fileTitle = getFileName(selectedFileUri);
            filePathTextView.setText(fileTitle);

            // 复制文件到应用缓存目录
            selectedFile = copyFileToCache(selectedFileUri, fileTitle);
        }
    }

    // 获取文件名
    private String getFileName(Uri uri) {
        String fileName = "Unknown File";
        try {
            if (uri.getScheme().equals("content")) {
                try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        fileName = cursor.getString(nameIndex);
                    }
                }
            } else if (uri.getScheme().equals("file")) {
                fileName = new File(uri.getPath()).getName();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileName;
    }

    // 复制文件到缓存
    private File copyFileToCache(Uri uri, String fileName) {
        try {
            File cacheFile = new File(getCacheDir(), fileName);
            try (InputStream inputStream = getContentResolver().openInputStream(uri);
                 FileOutputStream outputStream = new FileOutputStream(cacheFile)) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }
            }
            return cacheFile;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error copying file", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    // 验证输入
    private boolean validateInputs() {
        return !descriptionEditText.getText().toString().isEmpty() &&
                !maxScoreEditText.getText().toString().isEmpty() &&
                dueDate != null && !dueDate.isEmpty();
    }

    // 保存作业到数据库
    // 保存作业到数据库
    private void saveAssignmentToDatabase() {
        // 使用单线程执行数据库操作
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 插入 SQL 语句
                    String sql = "INSERT INTO assignments (course_id, title, description, file_path, due_date, max_score) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    // 设置占位符参数
                    stmt.setInt(1, courseId); // 课程 ID
                    stmt.setString(2, fileTitle); // 文件标题
                    stmt.setString(3, descriptionEditText.getText().toString()); // 描述
                    stmt.setString(4, selectedFile != null ? selectedFile.getAbsolutePath() : null); // 文件路径
                    stmt.setString(5, dueDate); // 截止日期
                    stmt.setInt(6, Integer.parseInt(maxScoreEditText.getText().toString())); // 最高分

                    // 执行插入操作
                    int rowsInserted = stmt.executeUpdate();
                    stmt.close();

                    // 更新 UI
                    runOnUiThread(() -> {
                        if (rowsInserted > 0) {
                            Toast.makeText(this, "Assignment saved successfully", Toast.LENGTH_SHORT).show();
                            finish(); // 关闭当前 Activity
                        } else {
                            Toast.makeText(this, "Failed to save assignment", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    // 数据库连接失败
                    runOnUiThread(() -> Toast.makeText(this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                // 捕获异常并显示错误信息
                runOnUiThread(() -> Toast.makeText(this, "Database error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    // 从数据库获取 course_id
    private void fetchCourseId() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    String query = "SELECT id AS course_id FROM courses WHERE course_code = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, courseCode);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        courseId = rs.getInt("course_id");

                        // 更新 UI
                        runOnUiThread(() ->
                                Toast.makeText(AssignmentUploadActivity.this, "Course ID fetched: " + courseId, Toast.LENGTH_SHORT).show());
                    } else {
                        runOnUiThread(() -> Toast.makeText(AssignmentUploadActivity.this, "Course code not found in database", Toast.LENGTH_SHORT).show());
                    }

                    rs.close();
                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(AssignmentUploadActivity.this, "Database connection failed", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(AssignmentUploadActivity.this, "Error fetching course ID: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}