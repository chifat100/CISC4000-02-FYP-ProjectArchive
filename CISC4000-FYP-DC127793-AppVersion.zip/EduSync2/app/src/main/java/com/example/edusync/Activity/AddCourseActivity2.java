package com.example.edusync.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddCourseActivity2 extends AppCompatActivity {

    private TextView tvCourseCode, tvCourseName, tvInstructorName, tvDescription;
    private Button btnAddCourse;
    private MysqlConnect mySQLConnect;
    private int courseId; // 传递的课程 ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course_2);

        // 初始化组件
        tvCourseCode = findViewById(R.id.CourseCode);
        tvCourseName = findViewById(R.id.CourseName);
        tvInstructorName = findViewById(R.id.Instructor);
        tvDescription = findViewById(R.id.Description);
        btnAddCourse = findViewById(R.id.btn_add_course);

        // 初始化数据库连接
        mySQLConnect = new MysqlConnect();

        // 获取 Intent 数据
        courseId = getIntent().getIntExtra("course_id", -1); // 获取课程 ID
        String courseCode = getIntent().getStringExtra("course_code");
        String courseName = getIntent().getStringExtra("course_name");
        String instructorName = getIntent().getStringExtra("instructor_name");
        String description = getIntent().getStringExtra("description");

        // 显示数据
        tvCourseCode.setText(courseCode);
        tvCourseName.setText(courseName);
        tvInstructorName.setText(instructorName);
        tvDescription.setText(description);

        // 从 SharedPreferences 中获取当前登录用户的 ID
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int studentId = sharedPreferences.getInt("user_id", -1);

        if (studentId == -1) {
            Toast.makeText(this, "用户未登录，请先登录", Toast.LENGTH_SHORT).show();
            return;
        }

        // 添加课程按钮点击事件
        btnAddCourse.setOnClickListener(v -> {
            if (courseId != -1) {
                addCourseToEnrollments(studentId, courseId);
            } else {
                Toast.makeText(this, "课程 ID 无效", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * 添加课程到 enrollments 表
     *
     * @param studentId 学生 ID
     * @param courseId  课程 ID
     */
    private void addCourseToEnrollments(int studentId, int courseId) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try (Connection conn = mySQLConnect.CONN()) {
                if (conn != null) {
                    // 检查是否已注册该课程
                    String checkQuery = "SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                    checkStmt.setInt(1, studentId);
                    checkStmt.setInt(2, courseId);
                    boolean alreadyEnrolled = checkStmt.executeQuery().next();
                    checkStmt.close();

                    if (alreadyEnrolled) {
                        runOnUiThread(() -> Toast.makeText(this, "你已注册该课程", Toast.LENGTH_SHORT).show());
                        return;
                    }

                    // 插入数据到 enrollments 表
                    String insertQuery = "INSERT INTO enrollments (student_id, course_id, status) VALUES (?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(insertQuery);
                    stmt.setInt(1, studentId);
                    stmt.setInt(2, courseId);
                    stmt.setString(3, "active");

                    int rowsInserted = stmt.executeUpdate();

                    runOnUiThread(() -> {
                        if (rowsInserted > 0) {
                            Toast.makeText(this, "课程添加成功", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "课程添加失败", Toast.LENGTH_SHORT).show();
                        }
                    });

                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "数据库连接失败", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "发生错误：" + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}