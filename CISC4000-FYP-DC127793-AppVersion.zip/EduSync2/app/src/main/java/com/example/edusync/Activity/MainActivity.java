package com.example.edusync.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.edusync.Adapter.CourseAdapter;
import com.example.edusync.Domain.CourseDomain;
import com.example.edusync.databinding.ActivityMainBinding;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    private MysqlConnect mySQLConnect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mySQLConnect = new MysqlConnect();

        initRecyclerView();
        initBottomNavigation();
        initAddCourseButton(); // Initialize Add Course button
    }

    // Initialize RecyclerView and populate data
    private void initRecyclerView() {
        ArrayList<CourseDomain> itemArrayList = new ArrayList<>();

        itemArrayList.add(new CourseDomain("Quick Learn C++ Language", "Jammie Young", 0, 4.8, "pic1"));
        itemArrayList.add(new CourseDomain("Full Course android kotlin", "Alex Alba", 0, 4.6, "pic2"));
        itemArrayList.add(new CourseDomain("Quick Learn C++ Language", "Jammie Young", 0, 4.5, "pic1"));

        binding.popularView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        binding.popularView.setAdapter(new CourseAdapter(itemArrayList));
    }

    // Add click events for bottom navigation
    private void initBottomNavigation() {
        // My Course click event
        binding.linearLayoutMyCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                String profileType = sharedPreferences.getString("profile_type", "");

                if (profileType.equalsIgnoreCase("student")) {
                    // Navigate to StudentCourseActivity for students
                    Intent intent = new Intent(MainActivity.this, StudentCourseActivity.class);
                    startActivity(intent);
                } else if (profileType.equalsIgnoreCase("instructor")) {
                    // Navigate to InstructorCourseActivity for instructors
                    Intent intent = new Intent(MainActivity.this, InstructorCourseActivity.class);
                    startActivity(intent);
                } else {
                    // Show error message for unknown roles
                    Toast.makeText(MainActivity.this, "无法识别用户角色，请重新登录", Toast.LENGTH_SHORT).show();
                }
            }
        });
        binding.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 启用 handleLogout 方法
                handleLogout();
            }
        });
    }

    // Initialize Add Course button
    private void initAddCourseButton() {
        binding.addcourseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to AddCourseActivity
                Intent intent = new Intent(MainActivity.this, AddCourseActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     * Handles user logout
     */
    private void handleLogout() {
        // Retrieve user ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);

        if (userId != -1) {
            // Update last_login in the database
            updateLastLoginTime(userId);
        }

        // Clear user session from SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        // Navigate back to LoginActivity
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear activity stack
        startActivity(intent);

        // Show logout success message
        Toast.makeText(MainActivity.this, "已成功登出", Toast.LENGTH_SHORT).show();
    }

    /**
     * Updates the last login time in the database
     *
     * @param userId The ID of the user whose last login time is to be updated
     */
    private void updateLastLoginTime(int userId) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                Connection con = mySQLConnect.CONN();
                if (con != null) {
                    // Get current timestamp
                    String currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

                    // Update last_login field for the user
                    String query = "UPDATE users SET last_login = ? WHERE id = ?";
                    PreparedStatement preparedStatement = con.prepareStatement(query);
                    preparedStatement.setString(1, currentTime);
                    preparedStatement.setInt(2, userId);

                    int rowsAffected = preparedStatement.executeUpdate();
                    if (rowsAffected > 0) {
                        // Update successful
                        runOnUiThread(() -> Log.d("Logout", "Last login time updated successfully."));
                    }

                    // Close resources
                    preparedStatement.close();
                    con.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "数据库连接失败", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "发生错误：" + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }
}