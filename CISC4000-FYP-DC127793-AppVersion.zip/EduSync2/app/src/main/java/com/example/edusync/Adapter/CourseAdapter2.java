package com.example.edusync.Activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Domain.Course;
import com.example.edusync.R;

import java.util.ArrayList;

public class CourseAdapter2 extends RecyclerView.Adapter<CourseAdapter2.CourseViewHolder> {

    private ArrayList<Course> courseList;
    private OnCourseClickListener listener; // 点击事件回调

    public interface OnCourseClickListener {
        void onCourseClick(Course course);
    }

    public CourseAdapter2(ArrayList<Course> courseList, OnCourseClickListener listener) {
        this.courseList = courseList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_course_dashboard, parent, false);
        return new CourseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseViewHolder holder, int position) {
        Course course = courseList.get(position);
        holder.tvCourseCode.setText(course.getCourseCode());
        holder.tvCourseName.setText(course.getCourseName());
        holder.tvInstructorName.setText(course.getInstructorName());

        // 设置点击事件
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onCourseClick(course);
            }
        });
    }

    @Override
    public int getItemCount() {
        return courseList.size();
    }

    public static class CourseViewHolder extends RecyclerView.ViewHolder {
        TextView tvCourseCode, tvCourseName, tvInstructorName;

        public CourseViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCourseCode = itemView.findViewById(R.id.course_code);
            tvCourseName = itemView.findViewById(R.id.course_name);
            tvInstructorName = itemView.findViewById(R.id.ownerText);
        }
    }
}