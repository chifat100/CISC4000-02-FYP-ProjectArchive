package com.example.edusync.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Domain.ResourceModel;
import com.example.edusync.R;

import java.util.List;

public class ResourceAdapter extends RecyclerView.Adapter<ResourceAdapter.ResourceViewHolder> {

    private List<ResourceModel> resourceList;

    public ResourceAdapter(List<ResourceModel> resourceList) {
        this.resourceList = resourceList;
    }

    @NonNull
    @Override
    public ResourceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 加载 item_resource 布局
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_resource, parent, false);
        return new ResourceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ResourceViewHolder holder, int position) {
        // 获取当前资源
        ResourceModel resource = resourceList.get(position);

        // 绑定数据到视图
        holder.titleTextView.setText(resource.getTitle());
        holder.instructorNameTextView.setText(resource.getInstructorName());
        holder.dateTextView.setText(resource.getCreatedAt());
    }

    @Override
    public int getItemCount() {
        return resourceList.size();
    }

    // ViewHolder 内部类
    public static class ResourceViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, instructorNameTextView, dateTextView;

        public ResourceViewHolder(@NonNull View itemView) {
            super(itemView);

            // 初始化视图
            titleTextView = itemView.findViewById(R.id.tvTitle);
            instructorNameTextView = itemView.findViewById(R.id.tvInstructorName);
            dateTextView = itemView.findViewById(R.id.tvDate);
        }
    }
}