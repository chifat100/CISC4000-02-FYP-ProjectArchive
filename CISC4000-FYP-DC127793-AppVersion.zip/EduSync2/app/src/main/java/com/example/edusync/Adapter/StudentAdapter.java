package com.example.edusync.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edusync.Domain.Student;
import com.example.edusync.R;

import java.util.ArrayList;
import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {

    private List<Student> studentList;
    private List<Student> filteredList; // 用于搜索过滤

    // 构造函数
    public StudentAdapter(List<Student> studentList) {
        this.studentList = studentList;
        this.filteredList = new ArrayList<>(studentList); // 初始化过滤列表
    }

    // 更新学生列表
    public void updateStudentList(List<Student> newStudentList) {
        this.studentList = newStudentList;
        this.filteredList = new ArrayList<>(newStudentList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.viewholder_students, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student student = filteredList.get(position);

        if (student != null) {
            holder.tvStudentName.setText(student.getName());
            holder.tvStudentID.setText(student.getStudentId());
            holder.tvStudentEmail.setText(student.getEmail());
        }
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    // 搜索过滤功能
    public void filter(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(studentList);
        } else {
            for (Student student : studentList) {
                if (student.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(student);
                }
            }
        }
        notifyDataSetChanged();
    }

    public static class StudentViewHolder extends RecyclerView.ViewHolder {
        TextView tvStudentName, tvStudentID, tvStudentEmail;

        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStudentName = itemView.findViewById(R.id.tvStudentName);
            tvStudentID = itemView.findViewById(R.id.tvStudentID);
            tvStudentEmail = itemView.findViewById(R.id.tvStudentEmail);
        }
    }
}