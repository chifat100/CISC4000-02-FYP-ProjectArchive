package com.example.edusync.Activity;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSender {
    public static void sendEmail(String to, String subject, String body) {
        final String from = "t13822547@gmail.com"; // 替换为您的 Gmail 地址
        final String appPassword = "twph krod agrq efqu"; // 替换为 Google 生成的应用专用密码

        // 邮件配置属性
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com"); // Gmail SMTP 服务器
        props.put("mail.smtp.port", "587"); // TLS 端口号
        props.put("mail.smtp.auth", "true"); // 启用身份验证
        props.put("mail.smtp.starttls.enable", "true"); // 启用 STARTTLS

        // 创建邮件会话
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, appPassword); // 使用 Gmail 和应用专用密码
            }
        });

        try {
            // 创建邮件消息
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from)); // 发件人邮箱
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to)); // 收件人邮箱
            message.setSubject(subject); // 邮件标题
            message.setText(body); // 邮件内容

            // 发送邮件
            Transport.send(message);
            System.out.println("邮件发送成功！");
        } catch (Exception e) {
            e.printStackTrace(); // 打印错误日志
        }
    }
}