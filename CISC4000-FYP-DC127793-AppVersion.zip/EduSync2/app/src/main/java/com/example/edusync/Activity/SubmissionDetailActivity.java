package com.example.edusync.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.edusync.R;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SubmissionDetailActivity extends AppCompatActivity {

    private TextView studentNameTextView, fileNameTextView, statusTextView, submissionTimeTextView, highestScoreTextView;
    private EditText gradeEditText, feedbackEditText;
    private Button saveButton;
    private int assignmentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submission_detail);

        // 初始化视图
        studentNameTextView = findViewById(R.id.tvStudentNameDetail);
        fileNameTextView = findViewById(R.id.tvFileNameDetail);
        statusTextView = findViewById(R.id.tvStatusDetail);
        submissionTimeTextView = findViewById(R.id.tvSubmissionTimeDetail);
        highestScoreTextView = findViewById(R.id.tvHighestScore);
        gradeEditText = findViewById(R.id.tvGradeDetail);
        feedbackEditText = findViewById(R.id.tvFeedbackDetail);
        saveButton = findViewById(R.id.btnSave);

        // 获取传递的数据
        String studentName = getIntent().getStringExtra("student_name");
        String fileName = getIntent().getStringExtra("file_name");
        String status = getIntent().getStringExtra("status");
        String submissionTime = getIntent().getStringExtra("submission_time");
        assignmentId = getIntent().getIntExtra("assignment_id", -1); // 获取 assignment_id

        // 检查 assignment_id 是否有效
        if (assignmentId == -1) {
            Toast.makeText(this, "Assignment ID not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 将获取的数据设置到 TextView
        studentNameTextView.setText(studentName);
        fileNameTextView.setText(fileName);
        statusTextView.setText(status);
        submissionTimeTextView.setText(submissionTime);

        // 加载最高分
        fetchMaxScore();

        // 设置保存按钮点击事件
        saveButton.setOnClickListener(v -> saveFeedbackAndGrade());
    }

    private void fetchMaxScore() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 查询 max_score
                    String query = "SELECT max_score FROM assignments WHERE id = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setInt(1, assignmentId);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        int maxScore = rs.getInt("max_score"); // 获取 max_score

                        // 更新 UI
                        runOnUiThread(() -> highestScoreTextView.setText(" / " + maxScore));
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "Max score not found", Toast.LENGTH_SHORT).show());
                    }

                    rs.close();
                    stmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Failed to connect to database", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error fetching max score: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void saveFeedbackAndGrade() {
        // 获取用户输入的分数和反馈
        String grade = gradeEditText.getText().toString().trim();
        String feedback = feedbackEditText.getText().toString().trim();
        String studentName = studentNameTextView.getText().toString().trim(); // 从 TextView 获取学生姓名

        // 检查分数是否为空
        if (grade.isEmpty()) {
            Toast.makeText(this, "Please enter a grade", Toast.LENGTH_SHORT).show();
            return;
        }

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try (Connection conn = new MysqlConnect().CONN()) {
                if (conn != null) {
                    // 查询 student_id
                    String getStudentIdQuery = "SELECT id FROM users WHERE name = ?";
                    PreparedStatement getStudentIdStmt = conn.prepareStatement(getStudentIdQuery);
                    getStudentIdStmt.setString(1, studentName);
                    ResultSet rs = getStudentIdStmt.executeQuery();

                    if (rs.next()) {
                        int studentId = rs.getInt("id"); // 获取 student_id

                        // 动态构建 SQL 查询
                        String query;
                        if (feedback.isEmpty()) {
                            query = "UPDATE assignment_submissions SET grade = ?, status = 'graded' WHERE assignment_id = ? AND student_id = ?";
                        } else {
                            query = "UPDATE assignment_submissions SET grade = ?, feedback = ?, status = 'graded' WHERE assignment_id = ? AND student_id = ?";
                        }

                        PreparedStatement stmt = conn.prepareStatement(query);

                        // 动态设置参数
                        stmt.setString(1, grade);
                        if (!feedback.isEmpty()) {
                            stmt.setString(2, feedback);
                            stmt.setInt(3, assignmentId);
                            stmt.setInt(4, studentId);
                        } else {
                            stmt.setInt(2, assignmentId);
                            stmt.setInt(3, studentId);
                        }

                        int rowsAffected = stmt.executeUpdate();
                        if (rowsAffected > 0) {
                            runOnUiThread(() -> {
                                Toast.makeText(this, "Saved successfully", Toast.LENGTH_SHORT).show();
                                finish(); // 返回上一个 Activity
                            });
                        } else {
                            runOnUiThread(() -> Toast.makeText(this, "Failed to save data", Toast.LENGTH_SHORT).show());
                        }

                        stmt.close();
                    } else {
                        // 如果没有找到 student_id
                        runOnUiThread(() -> Toast.makeText(this, "Student not found", Toast.LENGTH_SHORT).show());
                    }

                    rs.close();
                    getStudentIdStmt.close();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Failed to connect to database", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error saving data: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }
}