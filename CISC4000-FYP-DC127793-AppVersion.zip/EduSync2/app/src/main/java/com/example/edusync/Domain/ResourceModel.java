package com.example.edusync.Domain;

public class ResourceModel {
    private String title;          // 文件名
    private String instructorName; // 上传者名称
    private String createdAt;      // 上传日期

    public ResourceModel(String title, String instructorName, String createdAt) {
        this.title = title;
        this.instructorName = instructorName;
        this.createdAt = createdAt;
    }

    // Getter 方法
    public String getTitle() {
        return title;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}