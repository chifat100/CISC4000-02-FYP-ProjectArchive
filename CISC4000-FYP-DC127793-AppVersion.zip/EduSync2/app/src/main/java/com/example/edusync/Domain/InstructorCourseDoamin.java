package com.example.edusync.Domain;

public class InstructorCourseDoamin {
}
